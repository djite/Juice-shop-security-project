# Évaluation de sécurité — OWASP Juice Shop

Projet réalisé dans le cadre de l'**Examen final pratique — Sécurité des données**
(L3 Cybersécurité). Rôle : *Cybersecurity Analyst / Junior DevSecOps Engineer*.

**Application cible :** [OWASP Juice Shop](https://github.com/juice-shop/juice-shop)
v20.2.0 (Node.js / Express + Angular, base SQLite via Sequelize) — application
web délibérément vulnérable proposée par l'OWASP.

## Structure du dépôt

```
project/
├── README.md                 ← ce fichier
├── Jenkinsfile               ← pipeline CI/CD de sécurité (SAST/SCA/Secret/DAST)
├── reports/                  ← sorties JSON réelles des outils
│   ├── semgrep-sast.json         (SAST — 146 findings)
│   ├── gitleaks-secrets.json     (Secret Detection — 69 leaks)
│   └── npm-audit-sca.json        (SCA — 45 vulnérabilités de dépendances)
├── screenshots/              ← captures (app, /ftp, exploitation)
├── security-config/          ← config des outils + quality gate
│   ├── evaluate_gate.py          (agrège les rapports et décide du déploiement)
│   ├── .gitleaks.toml
│   └── semgrep-ci.yml
└── remediation/              ← correctifs + preuves de vérification
    ├── login.fixed.ts            (V1 — SQLi login → requête paramétrée)
    ├── search.fixed.ts           (V2 — SQLi recherche → requête paramétrée)
    ├── basket.fixed.ts           (V3 — IDOR → contrôle d'accès object-level)
    ├── password-hashing.fixed.ts (V6 — MD5 → bcrypt)
    ├── secrets.remediation.md    (V5 — clé privée en dur → secret manager)
    └── verify-sqli-fix.js        (preuve exécutable de la correction SQLi)
```

## Comment exécuter le projet (application cible)

```bash
# Option Docker (recommandée)
docker run --rm -p 3000:3000 bkimminich/juice-shop
# → http://localhost:3000

# Option source
git clone https://github.com/juice-shop/juice-shop.git
cd juice-shop && npm install && npm start
```

## Comment lancer les analyses

```bash
# --- SAST (Semgrep) ---
docker run --rm -v "$PWD:/src" returntocorp/semgrep \
  semgrep --config p/owasp-top-ten --config p/javascript \
          --json --output reports/semgrep.json /src

# --- Secret Detection (Gitleaks) ---
docker run --rm -v "$PWD:/repo" zricethezav/gitleaks:latest \
  dir /repo --report-format json --report-path reports/gitleaks.json

# --- SCA (npm audit + OWASP Dependency-Check) ---
npm audit --json > reports/npm-audit.json
docker run --rm -v "$PWD:/src" owasp/dependency-check:latest \
  --scan /src --format JSON --project juice-shop --out reports/

# --- DAST (OWASP ZAP baseline, app lancée sur :3000) ---
docker run --rm -v "$PWD/reports:/zap/wrk:rw" ghcr.io/zaproxy/zaproxy:stable \
  zap-baseline.py -t http://localhost:3000 -J zap-baseline.json -r zap-baseline.html

# --- Décision de déploiement (quality gate) ---
python3 security-config/evaluate_gate.py reports
# → CRITICAL=.. HIGH=.. MEDIUM=.. LOW=..
# → DECISION=REJECT | CONDITIONS | ACCEPT
```

Le pipeline complet est automatisé dans le `Jenkinsfile` (6 étapes :
Checkout → Build → Security Analysis → Additional Check → Report → Notification).

## Outils utilisés

| Outil | Type | Détecte | Intervient |
|-------|------|---------|------------|
| Semgrep | SAST | injections, XSS, secrets en dur, mauvais patterns | après build, sur le code source |
| Gitleaks | Secret Detection | clés privées, tokens, credentials | sur le dépôt, en parallèle du SAST |
| npm audit / OWASP Dependency-Check | SCA | dépendances vulnérables (CVE) | après installation des dépendances |
| OWASP ZAP | DAST | vulnérabilités à l'exécution (en-têtes, XSS reflété, config) | application déployée en test |

## Principales vulnérabilités identifiées

| ID | Vulnérabilité | Composant | CWE |
|----|---------------|-----------|-----|
| V1 | SQL Injection (login bypass) | `routes/login.ts` | CWE-89 |
| V2 | SQL Injection (UNION, exfiltration) | `routes/search.ts` | CWE-89 |
| V3 | Broken Access Control / IDOR | `routes/basket.ts` | CWE-639 |
| V4 | Exposition de données sensibles (`/ftp`) | `server.ts` | CWE-548 / CWE-22 |
| V5 | Clé privée RSA codée en dur | `lib/insecurity.ts` | CWE-798 |
| V6 | Hachage faible des mots de passe (MD5) | `lib/insecurity.ts` | CWE-328 |
| V7 | Dépendances vulnérables | `package.json` | CWE-1104 / CWE-937 |

Détails, analyse CIA, remédiations et décision de déploiement : voir le
**rapport de sécurité** (`reports/rapport-securite.pdf`).

> ⚠️ Les correctifs de `remediation/` sont fournis à titre de démonstration.
> Juice Shop étant volontairement vulnérable, ils illustrent la bonne pratique
> sans être destinés à être fusionnés dans l'application d'origine.

# Captures d'écran

Placez ici les captures illustrant la démonstration (Livrable 3) :

- `01_home.png`            — page d'accueil de Juice Shop
- `02_ftp_listing.png`     — listing du répertoire /ftp (V4)
- `03_sqli_login.png`      — connexion admin via `' OR 1=1--` (V1)
- `04_sqli_union.png`      — exfiltration de la table Users (V2)
- `05_idor_basket.png`     — accès au panier d'un autre utilisateur (V3)
- `06_jenkins_pipeline.png`— exécution du pipeline (stage view)
- `07_gate_reject.png`     — quality gate : DECISION=REJECT

Les commandes d'exploitation correspondantes sont dans le rapport (§3) et
dans `../remediation/verify-sqli-fix.js` pour la vérification des correctifs.

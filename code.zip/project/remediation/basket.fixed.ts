// =============================================================================
// REMÉDIATION V3 — Broken Access Control / IDOR sur les paniers (CWE-639)
// Fichier concerné : routes/basket.ts
// -----------------------------------------------------------------------------
// AVANT (vulnérable) : l'endpoint GET /rest/basket/:id charge le panier dont
// l'id est passé dans l'URL, SANS vérifier que ce panier appartient bien à
// l'utilisateur authentifié. Preuve obtenue : connecté sur le panier 1, la
// requête GET /rest/basket/2 renvoie le panier d'un autre utilisateur (200 OK).
//
// APRÈS (corrigé) : on compare l'id du panier demandé au bid (basket id)
// contenu dans le JWT de l'utilisateur. Si les deux diffèrent -> 401/403.
// C'est un contrôle d'accès « object-level » (autorisation par ressource),
// la parade recommandée contre l'IDOR.
// =============================================================================

import { type Request, type Response, type NextFunction } from 'express'
import { BasketModel } from '../models/basket'
import * as utils from '../lib/utils'
import * as security from '../lib/insecurity'

export function retrieveBasket () {
  return async (req: Request, res: Response, next: NextFunction) => {
    const requestedId = Number(req.params.id)

    // Identité issue du token signé, PAS d'un paramètre client falsifiable.
    const token = utils.jwtFrom(req)
    const decoded: any = security.verify(token) && security.decode(token)
    const ownBasketId = Number(decoded?.bid)

    if (!Number.isInteger(ownBasketId)) {
      return res.status(401).json({ error: 'Not authenticated' })
    }

    // Contrôle d'accès object-level : le panier demandé doit être le sien.
    if (requestedId !== ownBasketId) {
      return res.status(403).json({ error: 'Forbidden: this basket is not yours' })
    }

    try {
      const basket = await BasketModel.findOne({ where: { id: ownBasketId } })
      if (!basket) return res.status(404).json({ error: 'Basket not found' })
      res.json(utils.queryResultToJson(basket))
    } catch (error) {
      next(error as Error)
    }
  }
}

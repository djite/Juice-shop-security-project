// Preuve autonome : la requête paramétrée neutralise le payload SQLi.
// Exécuter :  node verify-sqli-fix.js   (nécessite: npm i sequelize sqlite3)
const { Sequelize, DataTypes, QueryTypes } = require('sequelize')

;(async () => {
  const db = new Sequelize('sqlite::memory:', { logging: false })
  const User = db.define('User', {
    email: DataTypes.STRING, password: DataTypes.STRING
  }, { tableName: 'Users', timestamps: false })
  await db.sync()
  await User.bulkCreate([
    { email: 'admin@juice-sh.op', password: 'secret-hash' },
    { email: 'user@juice-sh.op',  password: 'other-hash' }
  ])

  const payload = "' OR 1=1--"

  // 1) VULNÉRABLE : concaténation
  const vuln = await db.query(
    `SELECT * FROM Users WHERE email = '${payload}' AND password = 'x'`,
    { type: QueryTypes.SELECT })
  console.log('VULNÉRABLE  -> lignes renvoyées :', vuln.length,
              '(bypass', vuln.length > 0 ? 'RÉUSSI ❌)' : 'échoué)')

  // 2) CORRIGÉ : requête paramétrée
  const fixed = await db.query(
    `SELECT * FROM Users WHERE email = :email AND password = :pwd`,
    { replacements: { email: payload, pwd: 'x' }, type: QueryTypes.SELECT })
  console.log('PARAMÉTRÉE  -> lignes renvoyées :', fixed.length,
              '(bypass', fixed.length > 0 ? 'réussi)' : 'BLOQUÉ ✅)')

  await db.close()
})()

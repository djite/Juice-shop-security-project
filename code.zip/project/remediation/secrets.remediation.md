# Remédiation V5 — Secret (clé privée RSA) codé en dur (CWE-798)

**Fichier concerné :** `lib/insecurity.ts` (ligne 21)

## Cause
La clé privée RSA utilisée pour signer les JWT (`privateKey`) est écrite en
dur dans le code source. Toute personne ayant accès au dépôt (ou au bundle
front livré) peut la récupérer, forger des JWT valides et usurper n'importe
quel compte, y compris `admin`. Gitleaks détecte la règle `private-key` sur
cette ligne (voir `reports/gitleaks-secrets.json`).

## Correction
1. Retirer la clé du code et la charger depuis une variable d'environnement /
   coffre-fort de secrets :
   ```ts
   const privateKey = process.env.JWT_PRIVATE_KEY
   if (!privateKey) throw new Error('JWT_PRIVATE_KEY manquant')
   ```
2. Stocker la clé dans un gestionnaire de secrets (Jenkins Credentials,
   HashiCorp Vault, AWS Secrets Manager…), jamais dans Git.
3. **Roter la clé** : celle exposée dans l'historique Git est compromise,
   même après suppression. Purger l'historique (`git filter-repo`) et
   régénérer une nouvelle paire de clés.
4. Ajouter un pre-commit hook (Gitleaks) pour empêcher toute réintroduction.

## Vérification
- Relancer Gitleaks -> la règle `private-key` ne remonte plus sur
  `lib/insecurity.ts`.
- Vérifier qu'un JWT signé avec l'ancienne clé est désormais rejeté.

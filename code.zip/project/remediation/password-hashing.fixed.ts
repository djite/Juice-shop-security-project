// =============================================================================
// REMÉDIATION V6 — Hachage faible des mots de passe (CWE-328 / CWE-916)
// Fichier concerné : lib/insecurity.ts (ligne 41)
// -----------------------------------------------------------------------------
// AVANT (vulnérable) :
//   export const hash = (data: string) => crypto.createHash('md5').update(data).digest('hex')
//
// MD5 est un hachage rapide, non salé, cassé pour le stockage de mots de passe.
// Les hachages exfiltrés via la SQLi (ex. admin = 0192023a7bbd73250516f069df18b500)
// se cassent instantanément dans une rainbow table -> mot de passe « admin123 ».
//
// APRÈS (corrigé) : bcrypt, avec un facteur de coût (salage automatique,
// fonction lente et paramétrable). Impossible à pré-calculer en rainbow table.
// =============================================================================

import bcrypt from 'bcryptjs'

const COST_FACTOR = 12 // ajustable selon la puissance CPU cible

export const hashPassword = async (plain: string): Promise<string> => {
  return bcrypt.hash(plain, COST_FACTOR) // sel généré et intégré au hachage
}

export const verifyPassword = async (plain: string, stored: string): Promise<boolean> => {
  return bcrypt.compare(plain, stored)
}

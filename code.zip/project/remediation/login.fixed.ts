// =============================================================================
// REMÉDIATION V1 — Injection SQL sur l'authentification (CWE-89)
// Fichier concerné : routes/login.ts (ligne 34)
// -----------------------------------------------------------------------------
// AVANT (vulnérable) :
//
//   models.sequelize.query(
//     `SELECT * FROM Users WHERE email = '${req.body.email || ''}'
//      AND password = '${security.hash(req.body.password || '')}'
//      AND deletedAt IS NULL`,
//     { model: UserModel, plain: true })
//
// La chaîne email est concaténée directement dans la requête. Le payload
//   email = ' OR 1=1--
// transforme la clause WHERE en « toujours vraie » et connecte le premier
// utilisateur de la table (admin), sans mot de passe valide.
//
// APRÈS (corrigé) : on n'écrit plus de SQL à la main. On utilise l'API de
// haut niveau de Sequelize (UserModel.findOne + clause where objet), qui
// génère une requête paramétrée : la valeur fournie par l'utilisateur est
// transmise comme paramètre lié (bind parameter), jamais comme fragment SQL.
// Le payload « ' OR 1=1-- » est alors traité comme une adresse e-mail
// littérale, qui ne correspond à aucun compte -> échec de connexion.
// =============================================================================

import { type Request, type Response, type NextFunction } from 'express'
import { UserModel } from '../models/user'
import * as security from '../lib/insecurity'
import * as utils from '../lib/utils'

export function login () {
  return (req: Request, res: Response, next: NextFunction) => {
    // Requête paramétrée : Sequelize lie email et password comme paramètres.
    UserModel.findOne({
      where: {
        email: req.body.email || '',
        // Remarque : le hachage lui-même doit aussi être corrigé (voir V6,
        // remplacement de MD5 par bcrypt). On garde ici security.hash pour
        // isoler la correction de l'injection SQL.
        password: security.hash(req.body.password || '')
        // deletedAt IS NULL est géré automatiquement par le mode « paranoid »
        // du modèle Sequelize (soft delete).
      }
    })
      .then((authenticatedUser) => {
        const user = utils.queryResultToJson(authenticatedUser)
        if (!user.data?.id) {
          return res.status(401).send('Invalid email or password')
        }
        const token = security.authorize(user)
        res.json({ authentication: { token, bid: user.data.bid, umail: user.data.email } })
      })
      .catch((error: Error) => next(error))
  }
}

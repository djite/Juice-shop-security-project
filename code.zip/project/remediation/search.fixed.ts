// =============================================================================
// REMÉDIATION V2 — Injection SQL (UNION-based) sur la recherche produits (CWE-89)
// Fichier concerné : routes/search.ts (ligne 23)
// -----------------------------------------------------------------------------
// AVANT (vulnérable) :
//
//   models.sequelize.query(
//     `SELECT * FROM Products WHERE ((name LIKE '%${criteria}%'
//      OR description LIKE '%${criteria}%') AND deletedAt IS NULL)
//      ORDER BY name`)
//
// Le paramètre de recherche `criteria` est concaténé dans le SQL. Un payload
// UNION SELECT ... FROM Users -- permet d'exfiltrer la table des utilisateurs
// (adresses e-mail + hachages MD5 des mots de passe). Preuve obtenue :
//   /rest/products/search?q=...UNION SELECT id,email,password,... FROM Users--
//   -> 24 lignes renvoyées, incluant admin@juice-sh.op et son hash.
//
// APRÈS (corrigé) : requête paramétrée avec « replacements ». La valeur
// utilisateur est passée hors de la chaîne SQL ; Sequelize l'échappe et la
// lie. Le fragment UNION est alors interprété comme du texte recherché, pas
// comme du SQL.
// =============================================================================

import { Request, Response, NextFunction } from 'express'
import * as models from '../models/index'
import { QueryTypes } from 'sequelize'

export function searchProducts () {
  return (req: Request, res: Response, next: NextFunction) => {
    const criteria: string = String(req.query.q ?? '')

    models.sequelize.query(
      `SELECT * FROM Products
         WHERE ((name LIKE :like OR description LIKE :like) AND deletedAt IS NULL)
         ORDER BY name`,
      {
        replacements: { like: `%${criteria}%` }, // paramètre lié
        type: QueryTypes.SELECT
      }
    )
      .then((products: any[]) => {
        // Défense en profondeur : on ne renvoie que les colonnes publiques,
        // ce qui limite l'impact même si une injection passait (principe du
        // moindre privilège sur la sortie).
        const safe = products.map((p) => ({
          id: p.id, name: p.name, description: p.description, price: p.price, image: p.image
        }))
        res.json({ status: 'success', data: safe })
      })
      .catch((error: Error) => next(error))
  }
}

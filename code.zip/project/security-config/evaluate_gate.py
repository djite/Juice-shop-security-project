#!/usr/bin/env python3
"""
evaluate_gate.py — Agrège les rapports des outils de sécurité et rend une
décision de déploiement (Partie 5 de l'examen).

Règle (quality gate) :
  - au moins 1 Critical           -> REJECT   (bloquer le déploiement)
  - au moins 1 High (pas de Crit)  -> CONDITIONS (accepter sous conditions)
  - seulement Medium/Low           -> ACCEPT

Usage : python3 evaluate_gate.py <reports_dir>
Tolérant aux fichiers manquants : un outil absent ne casse pas l'évaluation.
"""
import json
import os
import sys

reports = sys.argv[1] if len(sys.argv) > 1 else "reports"


def load(name):
    path = os.path.join(reports, name)
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}

# --- SCA : npm audit -------------------------------------------------------
audit = load("npm-audit.json") or load("npm-audit-sca.json")
if audit and "metadata" in audit:
    v = audit["metadata"].get("vulnerabilities", {})
    counts["critical"] += v.get("critical", 0)
    counts["high"] += v.get("high", 0)
    counts["medium"] += v.get("moderate", 0)
    counts["low"] += v.get("low", 0)

# --- SAST : Semgrep --------------------------------------------------------
sast = load("semgrep.json") or load("semgrep-sast.json")
if sast and "results" in sast:
    sev_map = {"ERROR": "high", "WARNING": "medium", "INFO": "low"}
    for r in sast["results"]:
        sev = sev_map.get(r.get("extra", {}).get("severity", "INFO"), "low")
        counts[sev] += 1

# --- Secret Detection : Gitleaks ------------------------------------------
# Un secret exposé (clé privée, credential) est traité comme High au minimum.
secrets = load("gitleaks.json") or load("gitleaks-secrets.json")
if isinstance(secrets, list):
    real = [s for s in secrets
            if "/test/" not in s.get("File", "") and ".spec." not in s.get("File", "")]
    high_secrets = [s for s in real if s.get("RuleID") == "private-key"]
    counts["critical"] += len(high_secrets)          # clé privée = critique
    counts["high"] += len(real) - len(high_secrets)

# --- DAST : ZAP baseline ---------------------------------------------------
zap = load("zap-baseline.json")
if zap and "site" in zap:
    risk = {"3": "high", "2": "medium", "1": "low"}   # 3=High,2=Medium,1=Low
    for site in zap["site"]:
        for alert in site.get("alerts", []):
            sev = risk.get(str(alert.get("riskcode")), "low")
            counts[sev] += 1

# --- Décision --------------------------------------------------------------
if counts["critical"] > 0:
    decision = "REJECT"
elif counts["high"] > 0:
    decision = "CONDITIONS"
else:
    decision = "ACCEPT"

print(f"CRITICAL={counts['critical']} HIGH={counts['high']} "
      f"MEDIUM={counts['medium']} LOW={counts['low']}")
print(f"DECISION={decision}")
